function [Bloom] = BloomInit(n)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
    Bloom = zeros(1,n);
end

