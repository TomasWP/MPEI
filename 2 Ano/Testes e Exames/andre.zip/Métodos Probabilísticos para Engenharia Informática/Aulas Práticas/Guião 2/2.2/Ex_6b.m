lambda=8000*0.001;
 k=7;

 pk=((lambda^k)/factorial(k))*exp(-lambda) 