Sx = [5 50 100];
probs = [90 9 1]/100;

stem(Sx, probs)
axis([0 105 0 1])
grid on