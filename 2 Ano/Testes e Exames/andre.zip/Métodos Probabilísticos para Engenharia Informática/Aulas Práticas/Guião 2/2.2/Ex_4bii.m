prob_teorica0 = prob_teorica(0,5,0.3);
prob_teorica1 = prob_teorica(1,5,0.3);
prob_teorica2 = prob_teorica(2,5,0.3);

probTeoMax2 = prob_teorica0 + prob_teorica1 + prob_teorica2