function filtro = inicializarFiltro(n)
    filtro = zeros(n,1);
end