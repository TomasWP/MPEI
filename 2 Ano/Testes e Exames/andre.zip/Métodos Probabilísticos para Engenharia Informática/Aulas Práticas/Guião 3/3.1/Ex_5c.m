T = [0.7 0.2 0.3 ; 0.2 0.3 0.3 ; 0.1 0.5 0.4];

Sol1 = 1;
Chuva2 = T(3,1);
Chuva3 = Chuva2*T(3,3);

naoChuva3 = 1-Chuva3