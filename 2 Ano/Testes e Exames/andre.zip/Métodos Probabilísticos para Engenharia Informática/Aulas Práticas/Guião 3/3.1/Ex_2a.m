T = [1/3 1/4 0 ; 1/3 11/20 1/2 ; 1/3 1/5 1/2]

disp("É estocástica pois não temos entradas negativas e a soma de cada coluna dá sempre 1");