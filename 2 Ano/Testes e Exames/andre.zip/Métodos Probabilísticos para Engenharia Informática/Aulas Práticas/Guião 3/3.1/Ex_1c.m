T = [0.7,0.8 ; 0.3,0.2];
X_nfaltar = [1 ; 0]; 
T29 = T^(2*15-1);

res_matriz = (T29*X_nfaltar);
prob = res_matriz(1)