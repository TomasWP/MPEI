N = 10000;
n = 5;
p = 0.30;
d = 3;

prob = probSimulacao(p,n,d,N)
