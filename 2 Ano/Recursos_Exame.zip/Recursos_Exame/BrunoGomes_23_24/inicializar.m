function [x] = inicializar(n)
% inicializar vetor de dimensão n com zeros

x = zeros(n,1,'uint8');


end