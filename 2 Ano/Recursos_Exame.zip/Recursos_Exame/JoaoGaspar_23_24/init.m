function BF = init(n)
    BF = zeros(1,n);
end