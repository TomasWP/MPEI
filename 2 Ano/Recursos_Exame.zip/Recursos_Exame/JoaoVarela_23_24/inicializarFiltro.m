function filtro = inicializarFiltro(n)
    filtro = false(n,1);
end