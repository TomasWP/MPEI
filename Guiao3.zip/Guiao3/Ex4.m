p = 0.4;
q = 0.6;


% Matriz de transição

matriz_transicao = [p^2, 0, 0, q^2 ; (1-p)^2, 0, 0, q*(1-q) ; p*(1-p), 0, 0, q*(1-q) ; p*(1-p), 1, 1, (1-q)^2];      %       A       B       C       D
                                                                                                                    %  A   p^2      0       0      q^2
                                                                                                                    %  B  (1-p)^2   0       0      q*(1-q)
                                                                                                                    %  C  p*(1-p)   0       0      q*(1-q)
                                                                                                                    %  D  p*(1-p)   1       1      (1-q)^2


sum(matriz_transicao)



num_transicoes = [5, 10, 100, 200];

for i = 1:length(num_transicoes)
    matriz_probabilidade = matriz_transicao ^ num_transicoes(i);
    for estado = 1:4
        probabilidade = matriz_probabilidade(estado, 1);
        fprintf('A probabilidade do sistema estar no estado %d após %d transições é %.5f%%\n', estado, num_transicoes(i), probabilidade * 100); 
    end
end