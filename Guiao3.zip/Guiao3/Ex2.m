% Definir a matriz de transição
P = [1/3, 1/4, 0 ; 1/3, 11/20, 1/2 ; 1/3, 1/5, 1/2]; %   A      B       C
                                                    %    1/3    1/4     0
                                                    %    1/3    11/20   1/2
                                                    %    1/3    1/5     1/2
estado_inicial = [60 ; 15 ; 15];
num_aulas = 30;

% Iteração para 30 aulas
for aula = 1:num_aulas
    estado_inicial = P * estado_inicial;
end

round(estado_inicial)


% (d)

estado_inicial = [30 ; 30 ; 30];

% Iteração para 30 aulas
for aula = 1:num_aulas
    estado_inicial = P * estado_inicial;
end

round(estado_inicial)