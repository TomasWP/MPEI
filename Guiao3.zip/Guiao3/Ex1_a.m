% Definir a matriz de transição
P = [0.7, 0.8 ; 0.3, 0.2]; %   Estado1     Estado2
                        %     0.7          0.2
                        %     0.3          0.8


% Vetor de estado inicial [Presente, Faltou]
estado_inicial = [1 ; 0];  % Suponha que o aluno estava "Presente" na semana atual
                         % 1 Presente
                         % 0

% Calcular a probabilidade de estar "Presente" na semana seguinte
probabilidade_presente_semana_seguinte = P^2 * estado_inicial;  % Calcula a probabilidade na segunda Semana
    
fprintf('a) %.2f\n', probabilidade_presente_semana_seguinte(1));