% (d) Representação gráfica da probabilidade de faltar a cada uma das 30 aulas, assumindo que a probabilidade de estar presente na primeira aula é de 85%.
% Definir a matriz de transição
P = [0.7, 0.8 ; 0.3, 0.2]; %   Estado1     Estado2
                        %     0.7          0.8
                        %     0.3          0.2
num_aulas = 30;
prob_inicial = [0.85; 0.15]; % Começa na aula presente
prob_ausente = zeros(1, num_aulas);

% Iteração para 30 aulas
for aula = 1:num_aulas
    prob_ausente(aula) = 1 - prob_inicial(1);
    prob_inicial = P * prob_inicial;
end

% Plotagem das probabilidades
aulas = 1:num_aulas;
figure;
plot(aulas, prob_ausente, 'b');
xlabel('Aulas');
ylabel('Probabilidade de estar ausente');
title('(d) Probabilidade de faltar a cada uma das 30 aulas');